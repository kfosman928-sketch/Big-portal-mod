#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>

using namespace geode::prelude;

namespace {
    // 1.50 = 150% of the normal portal size.
    constexpr float BIG_PORTAL_SCALE = 1.50f;

    // Geometry Dash 2.2081 player-mode portal object IDs.
    // These are the mode-changing portals, not gravity/speed/trigger objects.
    bool isPlayerModePortal(int objectID) {
        switch (objectID) {
            case 10:  // Cube
            case 11:  // Ship
            case 12:  // Ball
            case 13:  // UFO
            case 47:  // Wave
            case 99:  // Robot
            case 101: // Spider
            case 286: // Swing
                return true;
            default:
                return false;
        }
    }

    void applyBigPortal(GameObject* object) {
        if (!object) return;

        if (isPlayerModePortal(object->m_objectID)) {
            // Portal objects are visual transition objects; enlarge the portal
            // sprite without changing the player's physics or movement settings.
            object->setScale(BIG_PORTAL_SCALE);
        }
    }
}

class $modify(BigPortalPlayLayer, PlayLayer) {
    void addObject(GameObject* object) {
        PlayLayer::addObject(object);
        applyBigPortal(object);
    }
};
