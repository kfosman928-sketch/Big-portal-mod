# Big Portal — Geode source project

Target: Geometry Dash **2.2081**.

## Feature implemented in source

- Enlarges the eight player-mode portals (cube, ship, ball, UFO, wave, robot, spider, and swing) to **150%** of their normal size when they are added during gameplay.
- Does not intentionally change player mode, gravity, speed, or movement physics.

## Important build status

This is a Geode **source project**, not a compiled `.geode` package. The C++ implementation has been written against the 2.2081 Geode bindings, but it has **not been compiled or tested in Geometry Dash** in this environment. A successful Android build is still required before installation.

## Build requirements

Use the Geode SDK/CLI version compatible with the `geode` field in `mod.json` and configure the Android toolchain for the target ABI. From the project directory, run:

```sh
geode build
```

A ZIP cannot be converted by renaming it to `.geode`; the source must be compiled for Android.

## Android 32-bit cloud build

This project includes `.github/workflows/build-android32.yml`. After uploading the project to a GitHub repository, run the workflow from the repository's Actions tab (or push to the `main` branch). It asks the Geode build action to target `Android32` and uploads the resulting `.geode` file as an artifact if compilation succeeds.

This workflow configuration is prepared but has not been run here. A successful GitHub Actions run is required to produce and verify the installable `.geode` package. Android 32-bit compatibility also depends on the device's Android build and the installed Geometry Dash/Geode versions.
